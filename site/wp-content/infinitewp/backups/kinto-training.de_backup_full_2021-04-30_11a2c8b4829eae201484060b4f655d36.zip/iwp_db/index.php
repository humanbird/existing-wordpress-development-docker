<?php
			global $old_url, $old_file_path;
			$old_url = 'https://kinto-training.de';
			$old_file_path = '/var/www/clients/client4/web3/web/';
			